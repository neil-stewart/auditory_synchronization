
#We plot using Cairo, because the plots look nice and have good anti aliasing
library("Cairo")

#This is for Figure 1
setwd("Data/S1")
Cairo(file='Fig1.png', type="png", width = 1400, height = 800, units = "px", pointsize = 25,quality=100)
par(mfrow=c(1,2))
#Some of these have odd names (e.g. "-rep3") because I had to run the BBTK test several times due to noise triggering the voicekey or similar
dataSets<-c("sep-officepc-ie-js.csv","sep-officepc-ff-js.csv","sep-officepc-cr-js.csv","sep-officepc-ie-js-rep3.csv","sep-officepc-ff-js-rep.csv","sep-officepc-cr-js-rep.csv","sep-officepc-ie-js-rep2016.csv","sep-officepc-ff-js-rep2016.csv","sep-officepc-cr-js-rep2016.csv")
#the '23' is to show it's a 2x3 plot not a 3x2 plot required - see function to make sense of that
plot_output(dataSets,23)
dataSets<-c("sep-officepc-ie-fl.csv","sep-officepc-ff-fl.csv","sep-officepc-cr-fl.csv","sep-officepc-ie-fl-rep.csv","sep-officepc-ff-fl-rep2.csv","sep-officepc-cr-fl-rep.csv","sep-officepc-ie-fl-rep2016.csv","sep-officepc-ff-fl-rep2016.csv","sep-officepc-cr-fl-rep2016.csv")
plot_output(dataSets,23)
legend(-100, 70, c("Internet Explorer", "Firefox", "Chrome"), lty= c(1,1,1), lwd=c(3,3,3),col=c(col1,col2,col3) )
dev.off()

#This is for Figure 2
setwd("../S2")
Cairo(file='Fig2.png', type="png", width = 1400, height = 800, units = "px", pointsize = 25,quality=100)
par(mfrow=c(1,2))
#Figure 2: Sync, 2 Panels - JS (officepc, lenlap), Fla (officepc, lenlap)
#Panel 1: JavaScript
dataSets<-c("sync-officepc-ie-js-rep3.csv","sync-officepc-ff-js.csv","sync-officepc-cr-js.csv","sync-lenlap-ed-js.csv","sync-lenlap-ff-js.csv","sync-lenlap-cr-js.csv")
plot_output(dataSets,32)
#Panel 2: Flash
dataSets<-c("sync-officepc-ie-fl.csv","sync-officepc-ff-fl.csv","sync-officepc-cr-fl.csv","sync-lenlap-ed-fl.csv","sync-lenlap-ff-fl.csv","sync-lenlap-cr-fl.csv")
plot_output(dataSets,32)
dev.off()

#And this is for Figure 3
setwd("../S3")
Cairo(file='Fig3.png', type="png", width = 1400, height = 800, units = "px", pointsize = 25,quality=100)
par(mfrow=c(1,2))
dataSets<-c("jswa-officepc-ff-js.csv","jswa-officepc-cr-js.csv", "jswa-officepc-ff-js-wav.csv","jswa-officepc-cr-js-wav.csv")
plot_output(dataSets,0)
# Web Audio Figure 1 - order IE, Firefox, Chrome
dataSets<-c("jswa-lenlap-ed-js.csv","jswa-lenlap-ff-js.csv","jswa-lenlap-cr-js.csv", "jswa-lenlap-ed-js-wav.csv", "jswa-lenlap-ff-js-wav.csv","jswa-lenlap-cr-js-wav.csv")
plot_output(dataSets,32)
dev.off()

#And, unsurprisingly, this is for Figure 4
setwd("../S4")
Cairo(file='Fig4.png', type="png", width = 1400, height = 800, units = "px", pointsize = 25,quality=100)
par(mfrow=c(1,2))
dataSets<-c("jswa2-officepc-ff-js.csv","jswa2-officepc-cr-js.csv","jswa2-officepc-ff-js-rep1.csv","jswa2-officepc-cr-js-rep1.csv","jswa2-officepc-ff-js-rep2.csv","jswa2-officepc-cr-js-rep2.csv")
plot_output(dataSets,23) #ie 2x3 reps
dataSets<-c("jswa2-lenlap-ed-js.csv","jswa2-lenlap-ff-js.csv","jswa2-lenlap-cr-js.csv","jswa2-lenlap-ed-js-rep1.csv","jswa2-lenlap-ff-js-rep1.csv","jswa2-lenlap-cr-js-rep1.csv","jswa2-lenlap-ed-js-rep2.csv","jswa2-lenlap-ff-js-rep2.csv","jswa2-lenlap-cr-js-rep2.csv")
plot_output(dataSets,0)
#legend(-100, 70, c("Edge", "Firefox", "Chrome"), lty= c(1,1,1), lwd=c(3,3,3),col=c(col1,col2,col3) )
dev.off()



#This function takes a dataset and plots the cumulative frequency of the asynchrony between audio and visual onsets
#cnd is used for appropriate colors for the lines (only relevant where number of lines = 6 - it could be three repetitions of two conditions or two of three)
plot_output <- function (dataSets, cnd){
  #ops is for the outputs, with one column for each dataSet whose name was passed to this function
  #We don't use it here, but you can return it if you want the actual onset asynchrony data
  ops <-NULL
  #cf is a data frame containing columns for each of the cumulative frequency distributions of the datasets used here
  cf<-NULL
  #This covers the range of asynchronies in all plots
  breaks = seq(-100, 150, by=1)
  #Go through all the dataset names passed to the function
  for(f in 1:length(dataSets)){
    #read in that dataset
    dSet <- read.csv(dataSets[f])
    #As this is pasted from BBTK output, it has annoying commas in, which confuses R. Remove them.
    dSet$Elapsed.mS <- gsub(",","", dSet$Elapsed.mS)
    #Vectors for all the visual and auditory onset and offset times
    vs_on<-NULL
    au_on<-NULL
    vs_off<-NULL
    au_off<-NULL
    #The BBTK has two identical opto inputs for recording visual onsets and offsets. In some trials the photoreceptor was plugged into Opto.1
    #In others it was plugged into Opto.2. Events from the two inputs are saved in different columns.
    #This next line just ensures that R gets the actual opto data rather than the column of 0s from the other input
    if(sum(dSet$Opto.1>0)) {opto=9} else {opto=8}
    #So, go through the event dataset row by row (each row is an event - i.e. visual on or off, or audio on or off), looking for onsets and offsets
    for(f in 2:nrow(dSet)) {
      #au_stat is the auditory status for this row - either 0 (no sound present) or 1 (sound present)
      au_stat<-dSet$Mic.1[f]
      #vs_stat is the visual status for this row - either 0 (no square present) or 1 (square present)
      vs_stat<-dSet[f,opto]
      #Get what the situations was on the on the previous row to see what's changed
      au_last<-dSet$Mic.1[f-1]
      vs_last<-dSet[f-1,opto] 
      #Work out what has changed, and append the time at which it occurred to the appropriate vector
      if(au_stat==1 && au_last==0) {au_on<-c(au_on,as.numeric(dSet$Elapsed.mS[f]))}
      if(vs_stat==1 && vs_last==0) {vs_on<-c(vs_on,as.numeric(dSet$Elapsed.mS[f]))}
      if(au_stat==0 && au_last==1) {au_off<-c(au_off,as.numeric(dSet$Elapsed.mS[f]))}
      if(vs_stat==0 && vs_last==1) {vs_off<-c(vs_off,as.numeric(dSet$Elapsed.mS[f]))}
      #so by the end of this for loop au_on will be a vector with all the auditory onset times
    }
    #Now, we're only looking at the first 100 trials - actual number varies, but is more than 100
    au_on<-au_on[1:100]
    vs_on<-vs_on[1:100]
    au_off<-au_off[1:100]
    vs_off<-vs_off[1:100]
    
    #If you want to plot visual durations, you can do that here:
    #hist(vs_off-vs_on)
    #If you want to plot auditory durations, you can do that here:
    #hist(au_off-au_on)
    #But this is what we're interested in plotting: visual-audio onset lag
    op<- au_on-vs_on
    #Add this as a column to the ops for all the datasets (though it isn't used here)
    ops <- cbind(ops,op)
    #We need to turn the current vector of asynchronies into a cumulative frequency for plotting
    #First we 'bin' the asynchronies into 1ms intervals (as a factor)
    fl.cut = cut(op, breaks, right=FALSE) 
    #Then we sum get the counts in each 1ms bin
    fl.freq = table(fl.cut)
    #And turn it into a cumulative frequency 
    cumfreqfl = c(0, cumsum(fl.freq)) 
    #And add that cumulative frequency as a column to cf
    cf <- cbind(cf,cumfreqfl)
  }
  
  #Colors for the plotting - trying to match to dominant colors used by the browsers (IE=Blue, Firefox=Orange, Chrome=Yellow)
  col3<<-"goldenrod3"
  col2<<-"darkorange4"
  col1<<-"dodgerblue2"
  
  #This isn't pretty, but it plots the cumulative frequencies appropriately
  #It checks the number of columns, and so infers the type of plot
  #This is just so we can have all the plotting in a single function
  #So, if there are four columns, it must be a 2x2 plot with browser (Firefox, Chrome) against something else (must mean that IE/Edge could not be used)
  if (ncol(cf)==4) {
    plot(breaks, cf[,1], type="l", col=col2, lwd=3, xlab="Lag (ms)", ylab="Cumulative Frequency (%)")
    lines(breaks, cf[,2], lwd=3,col=col3)
    lines(breaks, cf[,3], lty=2, lwd=3,col=col2) 
    lines(breaks, cf[,4], lty=2, lwd=3,col=col3)
  } 
  #If there are 6 colunns it could be one of two things - either three repetitions of two conditions
  #Or two repetitions of three conditious (the Figures in the paper have both)
  #So cnd is passed to the function to indicate which it is, and so color the line appropriately
  else if (ncol(cf)==6 && cnd==32){
    plot(breaks, cf[,1], type="l", col=col1, lwd=3, xlab="Lag (ms)", ylab="Cumulative Frequency (%)")
    lines(breaks, cf[,2], lwd=3,col=col2)
    lines(breaks, cf[,3], lwd=3,col=col3)
    lines(breaks, cf[,4],lty=2, lwd=3,col=col1)
    lines(breaks, cf[,5],lty=2, lwd=3,col=col2)
    lines(breaks, cf[,6], lty=2,lwd=3,col=col3)
  } else if (ncol(cf)==6 && cnd==23){
    plot(breaks, cf[,1], type="l", col=col2, lwd=3, xlab="Lag (ms)", ylab="Cumulative Frequency (%)")
    lines(breaks, cf[,2], lwd=3,col=col3)
    lines(breaks, cf[,3], lwd=3,col=col2)
    lines(breaks, cf[,4], lwd=3,col=col3)
    lines(breaks, cf[,5],lwd=3,col=col2)
    lines(breaks, cf[,6],lwd=3,col=col3)
  } 
  #And so on - this is for a 3x3 set of tests
  else if (ncol(cf)==9){
    plot(breaks, cf[,1], type="l", col=col1, lwd=3, xlab="Lag (ms)", ylab="Cumulative Frequency (%)")
    lines(breaks, cf[,2], lwd=3,col=col2)
    lines(breaks, cf[,3], lwd=3,col=col3)
    lines(breaks, cf[,4],lwd=3,col=col1)
    lines(breaks, cf[,5], lwd=3,col=col2)
    lines(breaks, cf[,6],lwd=3,col=col3)
    lines(breaks, cf[,7],lwd=3,col=col1)
    lines(breaks, cf[,8], lwd=3,col=col2)
    lines(breaks, cf[,9], lwd=3,col=col3)
  }
}


